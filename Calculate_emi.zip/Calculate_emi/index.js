// Function to fetch options from JSON and populate select element
const selectOptionsGenerator = async (selectId, fileName) => {
  try {
      const response = await fetch(fileName);
      if (!response.ok)
          throw new Error("Network error (not ok)");
      const options = await response.json();
      const selector = document.getElementById(selectId);

      Object.keys(options).forEach((key) => {
          const option = document.createElement('option');
          option.value = key;
          option.textContent = options[key].name;
          selector.appendChild(option);
      });
  } catch (error) {
      console.log(error);
  }
}

// Load options for payment mode, currency, and time period
selectOptionsGenerator('paymentMethods', 'paymentMethods.json');
selectOptionsGenerator('currencySelect', 'currency.json');
selectOptionsGenerator('timePeriod', 'timePeriod.json');

// Prevent form submission (if needed)
const form = document.getElementById("forms");
form.addEventListener("submit", (e) => {
  e.preventDefault();
  handleSubmit();
});

// Function to handle form submission and display key-value pairs
function handleSubmit() {
  const firstName = document.getElementById('name-f').value;
  const lastName = document.getElementById('name-l').value;
  const dob = document.getElementById('dob').value;
  const address = document.getElementById('address').value;
  const amount = document.getElementById('amount').value;
  const currency = document.getElementById('currencySelect').options[document.getElementById('currencySelect').selectedIndex].text;
  const paymentMethod = document.getElementById('paymentMethods').options[document.getElementById('paymentMethods').selectedIndex].text;
  const timePeriod = document.getElementById('timePeriod').options[document.getElementById('timePeriod').selectedIndex].text;
  const roi = document.getElementById('roi').value;
  const emi = document.getElementById('emi').value;

  // Display key-value pairs on the HTML page
  document.getElementById('firstNameDisplay').textContent = `First Name: ${firstName}`;
  document.getElementById('lastNameDisplay').textContent = `Last Name: ${lastName}`;
  document.getElementById('dobDisplay').textContent = `Date of Birth: ${dob}`;
  document.getElementById('addressDisplay').textContent = `Address: ${address}`;
  document.getElementById('amountDisplay').textContent = `Amount: ${amount}`;
  document.getElementById('currencySelectDisplay').textContent = `Currency: ${currency}`;
  document.getElementById('paymentMethodDisplay').textContent = `Payment Method: ${paymentMethod}`;
  document.getElementById('timePeriodDisplay').textContent = `Time Period: ${timePeriod}`;
  document.getElementById('roiDisplay').textContent = `Rate of Interest: ${roi}`;
  document.getElementById('emiDisplay').textContent = `EMI: ${emi}`;
}
